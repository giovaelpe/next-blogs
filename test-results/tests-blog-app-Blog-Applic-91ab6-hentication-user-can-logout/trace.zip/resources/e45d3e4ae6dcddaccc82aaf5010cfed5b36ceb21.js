(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_globals_0yg4wg8.css","static/chunks/node_modules_02xlrxs._.js","static/chunks/app_components_0twtsda._.js"],
    source: "dynamic"
});
